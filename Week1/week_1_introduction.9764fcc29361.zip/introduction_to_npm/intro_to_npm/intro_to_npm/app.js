var express = require('express'),
    cons = require('consolidate'),
    mongodb = require('mongodb');
